<?php

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'casino';

$conexion = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conexion) {
	// Registrar error para debugging y mostrar mensaje amigable al usuario
	error_log('DB connection error: ' . mysqli_connect_error());
	// Mensaje genérico para producción; incluye instrucción de reparación local
	die('Error: no se pudo conectar a la base de datos. Asegúrate de crear/importar la base `casino` (archivo bd/casino.sql) y revisar credenciales en conexion.php.');
}

mysqli_set_charset($conexion, 'utf8');