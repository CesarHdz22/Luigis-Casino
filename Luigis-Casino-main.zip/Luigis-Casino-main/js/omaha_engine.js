// Motor de evaluación para Omaha Hi: cada jugador tiene 4 cartas privadas,
// debe usar EXACTAMENTE 2 de sus privadas + EXACTAMENTE 3 de las comunitarias.
// Reutiliza la evaluación de 5 cartas del poker tradicional.

const pokerEngine = require('./poker_engine');

function combinations(arr, k) {
    const res = [];
    const n = arr.length;
    function go(start, chosen) {
        if (chosen.length === k) { res.push(chosen.slice()); return; }
        for (let i = start; i < n; i++) { chosen.push(arr[i]); go(i + 1, chosen); chosen.pop(); }
    }
    go(0, []);
    return res;
}

// Determina ganadores en Omaha: para cada jugador construye todas las combinaciones
// que usan 2 de sus 4 cartas más 3 de las comunitarias y elige la mejor.
function determineOmahaWinners(players, community) {
    const resultados = [];
    // community debe tener al menos 3 cartas para comparar
    if (!community || community.length < 3) return null;

    for (const p of players) {
        if (!p.active || p.fold) continue;
        const hole = p.cards || [];
        if (hole.length < 4) continue;

        let best = null;
        let bestHandCards = null;

        const holePairs = combinations(hole, 2); // C(4,2)=6
        const boardTrips = combinations(community, 3); // C(5,3)=10 max

        for (const hp of holePairs) {
            for (const bt of boardTrips) {
                const candidate = [...hp, ...bt]; // 5 cartas
                const evalRes = pokerEngine.evaluate5(candidate);
                if (!best) { best = evalRes; bestHandCards = candidate.slice(); }
                else {
                    const cmp = pokerEngine.compareEvaluatedLogic(evalRes, best);
                    if (cmp > 0) { best = evalRes; bestHandCards = candidate.slice(); }
                }
            }
        }

        if (best) resultados.push({ player: p, best, handCards: bestHandCards });
    }

    if (resultados.length === 0) return null;

    resultados.sort((a, b) => pokerEngine.compareEvaluatedLogic(b.best, a.best));

    const winners = [resultados[0]];
    for (let i = 1; i < resultados.length; i++) {
        if (pokerEngine.compareEvaluatedLogic(resultados[i].best, resultados[0].best) === 0) winners.push(resultados[i]);
        else break;
    }

    return { winners, all: resultados };
}

module.exports = { determineOmahaWinners };
