// Motor de evaluación de manos portado desde js/texas.js
const RANK_VALUE = {
    "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    "10": 10, "J": 11, "Q": 12, "K": 13, "A": 14
};

function combinations(arr, k) {
    const res = [];
    const n = arr.length;
    function go(start, chosen) {
        if (chosen.length === k) {
            res.push(chosen.slice());
            return;
        }
        for (let i = start; i < n; i++) {
            chosen.push(arr[i]);
            go(i + 1, chosen);
            chosen.pop();
        }
    }
    go(0, []);
    return res;
}

function evaluate5(cards5) {
    const vals = cards5.map(c => RANK_VALUE[c.valor]).sort((a, b) => b - a);

    const count = {};
    cards5.forEach(c => {
        const v = RANK_VALUE[c.valor];
        count[v] = (count[v] || 0) + 1;
    });

    const byCount = {};
    Object.keys(count).forEach(k => {
        const n = count[k];
        if (!byCount[n]) byCount[n] = [];
        byCount[n].push(Number(k));
    });
    Object.keys(byCount).forEach(k => byCount[k].sort((a, b) => b - a));

    const suits = {};
    cards5.forEach(c => suits[c.palo] = (suits[c.palo] || 0) + 1);
    const isFlush = Object.values(suits).some(x => x === 5);

    const uniqueVals = Array.from(new Set(vals)).sort((a, b) => b - a);
    let isStraight = false;
    let straightHigh = null;

    if (uniqueVals.length >= 5) {
        for (let i = 0; i <= uniqueVals.length - 5; i++) {
            const slice = uniqueVals.slice(i, i + 5);
            if (slice[0] - slice[4] === 4) {
                isStraight = true;
                straightHigh = slice[0];
                break;
            }
        }
        if (!isStraight) {
            const hasAce = uniqueVals.includes(14);
            const has5432 = [5, 4, 3, 2].every(v => uniqueVals.includes(v));
            if (hasAce && has5432) {
                isStraight = true;
                straightHigh = 5;
            }
        }
    }

    if (isFlush && isStraight) {
        return { rank: 9, tiebreaker: [straightHigh], name: (straightHigh === 14 ? 'Royal Flush' : 'Straight Flush') };
    }
    if (byCount[4]) {
        return { rank: 8, tiebreaker: [byCount[4][0]], name: 'Four of a Kind' };
    }
    if (byCount[3] && (byCount[2] || byCount[3].length > 1)) {
        const trip = byCount[3][0];
        const pair = byCount[2] ? byCount[2][0] : byCount[3][1];
        return { rank: 7, tiebreaker: [trip, pair], name: 'Full House' };
    }
    if (isFlush) {
        return { rank: 6, tiebreaker: vals.slice(0, 5), name: 'Flush' };
    }
    if (isStraight) {
        return { rank: 5, tiebreaker: [straightHigh], name: 'Straight' };
    }
    if (byCount[3]) {
        const kickers = vals.filter(v => v !== byCount[3][0]).slice(0, 2);
        return { rank: 4, tiebreaker: [byCount[3][0], ...kickers], name: 'Three of a Kind' };
    }
    if (byCount[2] && byCount[2].length >= 2) {
        const p1 = byCount[2][0];
        const p2 = byCount[2][1];
        const kicker = vals.filter(v => v !== p1 && v !== p2)[0];
        return { rank: 3, tiebreaker: [p1, p2, kicker], name: 'Two Pair' };
    }
    if (byCount[2]) {
        const p1 = byCount[2][0];
        const kickers = vals.filter(v => v !== p1).slice(0, 3);
        return { rank: 2, tiebreaker: [p1, ...kickers], name: 'One Pair' };
    }
    return { rank: 1, tiebreaker: vals.slice(0, 5), name: 'High Card' };
}

function compareEvaluatedLogic(a, b) {
    if (a.rank !== b.rank) {
        return a.rank - b.rank;
    }
    for (let i = 0; i < a.tiebreaker.length; i++) {
        const valA = a.tiebreaker[i] || 0;
        const valB = b.tiebreaker[i] || 0;
        if (valA !== valB) {
            return valA - valB;
        }
    }
    return 0;
}

function bestHandFrom7(cards7) {
    const combs = combinations(cards7, 5);
    let best = null;
    let bestHandCards = [];

    combs.forEach(c5 => {
        const result = evaluate5(c5);
        if (!best) {
            best = result;
            bestHandCards = c5;
        } else {
            const comparison = compareEvaluatedLogic(result, best);
            if (comparison > 0) {
                best = result;
                bestHandCards = c5;
            }
        }
    });

    return { best, bestHandCards };
}

function determineWinners(players, community) {
    const resultados = [];
    players.forEach(p => {
        if (p.active && !p.fold) {
            const pool = [...(p.cards || []), ...community];
            if (pool.length < 5) return;
            const mejor = bestHandFrom7(pool);
            resultados.push({ player: p, best: mejor.best, handCards: mejor.bestHandCards });
        }
    });

    if (resultados.length === 0) return null;

    resultados.sort((a, b) => {
        return compareEvaluatedLogic(b.best, a.best);
    });

    const winners = [resultados[0]];
    for (let i = 1; i < resultados.length; i++) {
        if (compareEvaluatedLogic(resultados[i].best, resultados[0].best) === 0) {
            winners.push(resultados[i]);
        } else break;
    }

    return { winners, all: resultados };
}

module.exports = { evaluate5, bestHandFrom7, compareEvaluatedLogic, determineWinners };
