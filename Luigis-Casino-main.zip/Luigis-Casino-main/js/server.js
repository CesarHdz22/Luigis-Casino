const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http, { cors: { origin: "*" } });

// Health endpoint para comprobar que el servidor Node está corriendo
app.get('/health', (req, res) => {
    res.json({ ok: true, ts: Date.now() });
});

// Endpoint HTTP para depuración: obtener lista de rooms (siempre disponible)
app.get('/rooms', (req, res) => {
    const rooms = [];
    for (const r in roomsGame) {
        const rg = roomsGame[r];
        let playersCount = 0;
        for (const pid of [1,2]) if (rg.players[pid] && rg.players[pid].username) playersCount++;
        const seatsRef = roomsSeats[r] || {};
        let seatsOccupied = 0;
        for (const sid in seatsRef) if (seatsRef[sid]) seatsOccupied++;
        rooms.push({ room: r, players: playersCount, seats: seatsOccupied, gameType: rg.gameType || 'omaha' });
    }
    res.json({ rooms });
});

// Middleware: validar token emitido por PHP
const fs = require('fs');
const path = require('path');
io.use((socket, next) => {
    try {
        const token = (socket.handshake && socket.handshake.auth && socket.handshake.auth.token) || (socket.handshake && socket.handshake.query && socket.handshake.query.token);
        if (!token) {
            console.warn('Socket auth: no token provided in handshake for socket', socket.id);
            return next(new Error('AUTH_ERROR: no token'));
        }

        // server.js está dentro de la carpeta `js`, así que el token store queda en el mismo directorio
        const storePath = path.join(__dirname, 'socket_tokens.json');

        // Loguear token parcialmente (no mostrarlo completo)
        const masked = String(token).length > 8 ? (String(token).slice(0,6) + '...' + String(token).slice(-2)) : token;
        console.log('Socket auth attempt, socket:', socket.id, 'token:', masked, 'storePath:', storePath);

        // Asegurar que el archivo exista (puede ser creado por PHP). Si no existe, intentar crear uno vacío.
        if (!fs.existsSync(storePath)) {
            try {
                fs.writeFileSync(storePath, JSON.stringify({}), { flag: 'w' });
                console.log('Created missing token store at', storePath);
            } catch (e) {
                console.error('Could not create token store at', storePath, e);
                return next(new Error('AUTH_ERROR: token store missing'));
            }
        }
        const content = fs.readFileSync(storePath, 'utf8');
        let store = {};
        try { store = JSON.parse(content || '{}'); } catch(e){ console.error('Invalid JSON in token store', e); return next(new Error('AUTH_ERROR: invalid token store')); }
        const entry = store[token];
        if (!entry || !entry.username) {
            console.warn('Token not found or invalid in store for token (masked):', masked, 'storeKeys:', Object.keys(store).length);
            return next(new Error('AUTH_ERROR: invalid token'));
        }

        // Token válido: asociar username al socket
        socket.username = entry.username;
        console.log('Socket authenticated:', socket.id, 'username:', socket.username);
        return next();
    } catch (err) {
        console.error('Token validation error', err);
        return next(new Error('AUTH_ERROR'));
    }
});

let seats = {
    1: null, 2: null, 3: null, 4: null,
    5: null, 6: null, 7: null, 8: null
};
// seats por habitación/mesa
const roomsSeats = {};
// Estado de juego por room (tablero, jugadores, bombas)
const roomsGame = {};

// Persistencia ligera: guardar/recuperar estado en disco para supervivencia a reinicios
// persist file colocado en el mismo directorio que este script
const PERSIST_FILE = path.join(__dirname, 'persist.json');
function loadPersist(){
    if (!fs.existsSync(PERSIST_FILE)) return;
    try{
        const raw = fs.readFileSync(PERSIST_FILE, 'utf8');
        const obj = JSON.parse(raw || '{}');
        if (obj.roomsSeats) Object.assign(roomsSeats, obj.roomsSeats);
        if (obj.roomsGame) Object.assign(roomsGame, obj.roomsGame);
        if (obj.pokerRooms) Object.assign(pokerRooms, obj.pokerRooms);
        if (obj.omahaRooms) Object.assign(omahaRooms, obj.omahaRooms);
        console.log('Persisted state loaded from', PERSIST_FILE);
    } catch(e){ console.error('Error loading persist file', e); }
}

function savePersist(){
    try{
        const out = { roomsSeats, roomsGame, pokerRooms, omahaRooms };
        fs.writeFileSync(PERSIST_FILE, JSON.stringify(out, null, 2), 'utf8');
    } catch(e){ console.error('Error saving persist file', e); }
}

// Helpers para crear tablero similar a cliente
function createRoomBoard() {
    const ROWS = 11, COLS = 13;
    const grid = [];
    for (let r = 0; r < ROWS; r++) {
        const row = [];
        for (let c = 0; c < COLS; c++) {
            let value = 'empty';
            if (r === 0 || c === 0 || r === ROWS - 1 || c === COLS - 1) {
                value = 'wall';
            } else if (r % 2 === 0 && c % 2 === 0) {
                value = 'wall';
            } else {
                // cajas aleatorias
                if (Math.random() < 0.3) value = 'crate';
            }
            row.push(value);
        }
        grid.push(row);
    }
    return { grid, ROWS, COLS };
}

function ensureRoomGame(room) {
    if (!roomsGame[room]) {
        const board = createRoomBoard();
        const players = { 1: null, 2: null };
        roomsGame[room] = { grid: board.grid, ROWS: board.ROWS, COLS: board.COLS, players, bombs: [] };
    }
    return roomsGame[room];
}

function isWalkableGrid(roomGame, r, c) {
    if (r < 0 || c < 0 || r >= roomGame.ROWS || c >= roomGame.COLS) return false;
    const type = roomGame.grid[r][c];
    return type === 'empty' || type === 'explosion';
}

function serverExplodeBomb(room, br, bc) {
    const roomGame = roomsGame[room];
    if (!roomGame) return;
    const RANGE = 2;
    const explosionCells = [];
    function add(rr, cc) {
        if (rr < 0 || cc < 0 || rr >= roomGame.ROWS || cc >= roomGame.COLS) return false;
        if (roomGame.grid[rr][cc] === 'wall') return false;
        if (roomGame.grid[rr][cc] === 'crate') {
            roomGame.grid[rr][cc] = 'explosion';
            explosionCells.push({r: rr, c: cc});
            return false;
        }
        roomGame.grid[rr][cc] = 'explosion';
        explosionCells.push({r: rr, c: cc});
        return true;
    }
    add(br, bc);
    for (let i = 1; i <= RANGE; i++) { if (!add(br - i, bc)) break; }
    for (let i = 1; i <= RANGE; i++) { if (!add(br + i, bc)) break; }
    for (let i = 1; i <= RANGE; i++) { if (!add(br, bc - i)) break; }
    for (let i = 1; i <= RANGE; i++) { if (!add(br, bc + i)) break; }

    // comprobar jugadores
    for (const pid of [1,2]) {
        const p = roomGame.players[pid];
        if (p && p.alive) {
            for (const pos of explosionCells) {
                if (p.row === pos.r && p.col === pos.c) {
                    p.alive = false;
                }
            }
        }
    }

    // limpiar bombas y reemplazar por empty tras explosion duration
    setTimeout(() => {
        explosionCells.forEach(pos => {
            if (roomGame.grid[pos.r][pos.c] === 'explosion') roomGame.grid[pos.r][pos.c] = 'empty';
        });
        io.to(room).emit('state', roomGame);
    }, 500);

    io.to(room).emit('state', roomGame);
}

// --- Poker Texas engine (simplificado) ---
const pokerRooms = {};
// Blinds por defecto
const SMALL_BLIND = 50;
const BIG_BLIND = 100;

// Motor de evaluación server-side
const pokerEngine = require('./poker_engine');
const omahaEngine = require('./omaha_engine');
const omahaRooms = {};

function createOmahaRoom(room) {
    if (omahaRooms[room]) return omahaRooms[room];
    omahaRooms[room] = {
        players: [], // {username, socketId, stack, seat, active, fold, cards:[] }
        deck: createDeckForPoker(),
        community: [],
        pot: 0,
        dealerIndex: -1,
        currentPlayerIndex: -1,
        phase: 'waiting',
        betToCall: 0,
        minBet: BIG_BLIND
    };
    return omahaRooms[room];
}

function dealOmahaPrivateCards(pr) {
    for (const p of pr.players) p.cards = [];
    // deal 4 cards
    for (let i = 0; i < 4; i++) {
        for (const p of pr.players) {
            if (p.active && !p.fold) p.cards.push(pr.deck.pop());
        }
    }
}

function sendPrivateToOwnersOmaha(room){
    const pr = omahaRooms[room];
    if (!pr) return;
    for (const p of pr.players) if (p.socketId) io.to(p.socketId).emit('omahaPrivate', { cards: p.cards, stack: p.stack, seat: p.seat, username: p.username });
}

function startOmahaHand(room) {
    const pr = createOmahaRoom(room);
    if (pr.players.filter(p=>p.active).length < 2) return { error: 'Se necesitan al menos 2 jugadores activos' };
    pr.dealerIndex = (pr.dealerIndex + 1) % pr.players.length;
    pr.pot = 0; pr.community = []; pr.phase = 'preflop'; pr.betToCall = BIG_BLIND; pr.deck = createDeckForPoker();
    for (const p of pr.players){ p.fold = false; p.cards = []; p.currentBet = 0; }
    // post blinds simplified
    let idx = pr.dealerIndex;
    idx = nextIndex(pr, idx);
    if (idx !== -1) { const small = pr.players[idx]; const sb = Math.min(SMALL_BLIND, small.stack); small.stack -= sb; pr.pot += sb; small.currentBet = sb; }
    idx = nextIndex(pr, idx);
    if (idx !== -1) { const big = pr.players[idx]; const bb = Math.min(BIG_BLIND, big.stack); big.stack -= bb; pr.pot += bb; big.currentBet = bb; pr.betToCall = bb; }
    // deal 4 cards
    dealOmahaPrivateCards(pr);
    pr.currentPlayerIndex = nextIndex(pr, idx);
    io.to(room).emit('omahaState', { players: pr.players.map(p=>({username:p.username,stack:p.stack,active:p.active,fold:p.fold,seat:p.seat})), community: pr.community, pot: pr.pot, phase: pr.phase, betToCall: pr.betToCall, dealerIndex: pr.dealerIndex, currentPlayerIndex: pr.currentPlayerIndex });
    sendPrivateToOwnersOmaha(room);
    return { ok: true };
}

function createPokerRoom(room) {
    if (pokerRooms[room]) return pokerRooms[room];
    const deck = createDeckForPoker();
    pokerRooms[room] = {
        players: [], // {username, socketId, stack, seat, active, fold, cards:[] }
        deck,
        community: [],
        pot: 0,
        dealerIndex: -1,
        currentPlayerIndex: -1,
        phase: 'waiting', // waiting, preflop, flop, turn, river, showdown
        betToCall: 0,
        minBet: BIG_BLIND
    };
    return pokerRooms[room];
}

// Helper: distribuir bote con side-pots basico usando committed amounts
function distributePotWithSidePots(pr){
    try{
        const players = pr.players.filter(p=>p.active);
        // collect unique positive contribution levels
        const contributions = players.map(p=>({ player: p, committed: p.committed || 0 }));
        const levels = Array.from(new Set(contributions.map(x=>x.committed))).filter(v=>v>0).sort((a,b)=>a-b);
        let prev = 0;
        for (const level of levels){
            const contribPlayers = contributions.filter(c=>c.committed >= level).map(c=>c.player);
            if (contribPlayers.length === 0) { prev = level; continue; }
            const potAmount = (level - prev) * contribPlayers.length;
            // eligible players for this sidepot are those who contributed at least `level` and are not folded
            const eligible = contribPlayers.filter(p=>!p.fold);
            if (eligible.length === 0) { prev = level; continue; }
            const evalRes = pokerEngine.determineWinners(eligible, pr.community);
            const winners = (evalRes && evalRes.winners && evalRes.winners.length>0) ? evalRes.winners.map(w=>w.player) : [eligible[0]];
            const share = Math.floor(potAmount / winners.length);
            for (const w of winners) w.stack += share;
            const remainder = potAmount - share * winners.length;
            if (remainder > 0) winners[0].stack += remainder;
            prev = level;
        }
        pr.pot = 0;
        // reset committed and currentBet for next hand
        for (const p of pr.players){ p.committed = 0; p.currentBet = 0; }
    } catch(e){ console.error('Error distributing side-pots', e); }
}

function createDeckForPoker() {
    const suits = ['♥','♦','♣','♠'];
    const ranks = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
    const d = [];
    for (const r of ranks) for (const s of suits) d.push({valor: r, palo: s});
    return shuffleArray(d);
}

function shuffleArray(arr){
    for (let i = arr.length-1; i>0; i--){
        const j = Math.floor(Math.random()*(i+1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

function dealPrivateCards(pr) {
    for (const p of pr.players) {
        p.cards = [];
    }
    // deal 2 cards
    for (let i=0;i<2;i++){
        for (const p of pr.players) {
            if (p.active && !p.fold) p.cards.push(pr.deck.pop());
        }
    }
}

function startPokerHand(room) {
    const pr = createPokerRoom(room);
    if (pr.players.filter(p=>p.active).length < 2) return { error: 'Se necesitan al menos 2 jugadores activos' };
    // rotate dealer
    pr.dealerIndex = (pr.dealerIndex + 1) % pr.players.length;
    pr.pot = 0;
    pr.community = [];
    pr.phase = 'preflop';
    pr.betToCall = BIG_BLIND;
    pr.deck = createDeckForPoker();

    // reset player states
    for (const p of pr.players){
        p.fold = false;
        p.cards = [];
        p.currentBet = 0;
    }

    // post blinds (simplified: first active after dealer posts small, next big)
    const activePlayers = pr.players.filter(p=>p.active);
    const dealer = pr.players[pr.dealerIndex];
    // find small/big
    let idx = pr.dealerIndex;
    // small
    idx = nextIndex(pr, idx);
    if (idx !== -1) {
        const small = pr.players[idx];
        const sb = Math.min(SMALL_BLIND, small.stack);
        small.stack -= sb; pr.pot += sb; small.currentBet = sb; small.committed = (small.committed||0) + sb;
    }
    // big
    idx = nextIndex(pr, idx);
    if (idx !== -1) {
        const big = pr.players[idx];
        const bb = Math.min(BIG_BLIND, big.stack);
        big.stack -= bb; pr.pot += bb; big.currentBet = bb; big.committed = (big.committed||0) + bb;
        pr.betToCall = bb;
    }

    // deal
    dealPrivateCards(pr);

    // set current player to next after big
    pr.currentPlayerIndex = nextIndex(pr, idx);

    // emit state
    io.to(room).emit('pokerState', sanitizePokerState(pr));
    savePersist();
    return { ok: true };
}

function nextIndex(pr, start){
    const n = pr.players.length;
    if (n === 0) return -1;
    for (let i=1;i<=n;i++){
        const idx = (start + i) % n;
        if (pr.players[idx].active && !pr.players[idx].sitOut) return idx;
    }
    return -1;
}

function sanitizePokerState(pr){
    // hide private cards except for owner when emitting to everyone; we'll send full to each socket separately
    const publicPlayers = pr.players.map(p=>({ username: p.username, stack: p.stack, active: p.active, fold: p.fold, seat: p.seat, currentBet: p.currentBet }));
    return { players: publicPlayers, community: pr.community, pot: pr.pot, phase: pr.phase, betToCall: pr.betToCall, dealerIndex: pr.dealerIndex, currentPlayerIndex: pr.currentPlayerIndex };
}

// helper to send private cards to owner
function sendPrivateToOwners(room){
    const pr = pokerRooms[room];
    if (!pr) return;
    for (const p of pr.players) {
        if (p.socketId) {
            io.to(p.socketId).emit('pokerPrivate', { cards: p.cards, stack: p.stack, seat: p.seat, username: p.username });
        }
    }
}

// handle player action (call, check, raise, fold)
function handlePokerAction(room, username, action){
    const pr = pokerRooms[room];
    if (!pr) return;
    const idx = pr.players.findIndex(p=>p.username===username);
    if (idx === -1) return;
    const player = pr.players[idx];
    if (!player.active || player.fold) return;

    switch(action.type){
        case 'fold':
            player.fold = true;
            break;
        case 'check':
            // only if current bet equals player's currentBet
            if (player.currentBet === pr.betToCall) {
                // ok
            } else {
                // invalid
            }
            break;
        case 'call':
            const toCall = pr.betToCall - (player.currentBet||0);
            const commit = Math.min(toCall, player.stack);
            player.stack -= commit; pr.pot += commit; player.currentBet = (player.currentBet||0)+commit; player.committed = (player.committed||0)+commit;
            break;
        case 'raise':
            const raiseAmount = Number(action.amount) || pr.minBet;
            const total = (pr.betToCall - (player.currentBet||0)) + raiseAmount;
            if (player.stack >= total){
                player.stack -= total; pr.pot += total; player.currentBet = (player.currentBet||0)+total; player.committed = (player.committed||0)+total; pr.betToCall = player.currentBet; pr.minBet = raiseAmount;
            } else {
                // all-in simplified
                const allin = player.stack;
                player.stack = 0; pr.pot += allin; player.currentBet = (player.currentBet||0)+allin; player.committed = (player.committed||0)+allin;
                if (player.currentBet > pr.betToCall) pr.betToCall = player.currentBet;
            }
            break;
    }

    // advance to next player
    pr.currentPlayerIndex = nextIndex(pr, idx);

    // check if betting round is over: simple heuristic - if every active non-fold player's currentBet equals betToCall
    const activePlayers = pr.players.filter(p=>p.active && !p.fold);
    let roundOver = activePlayers.every(p=> (p.currentBet||0) === pr.betToCall || p.stack===0);
    if (roundOver){
        // advance phase
        if (pr.phase === 'preflop'){
            // deal flop
            pr.phase = 'flop';
            // burn one
            pr.deck.pop();
            pr.community.push(pr.deck.pop()); pr.community.push(pr.deck.pop()); pr.community.push(pr.deck.pop());
        } else if (pr.phase === 'flop'){
            pr.phase = 'turn'; pr.deck.pop(); pr.community.push(pr.deck.pop());
        } else if (pr.phase === 'turn'){
            pr.phase = 'river'; pr.deck.pop(); pr.community.push(pr.deck.pop());
        } else if (pr.phase === 'river'){
            pr.phase = 'showdown';
        }
        // reset currentBets
        for (const p of pr.players) p.currentBet = 0;
        pr.betToCall = 0;
    }

    // emit public state and private cards
    io.to(room).emit('pokerState', sanitizePokerState(pr));
    sendPrivateToOwners(room);

    // if showdown, compute winner using server-side evaluator and split pozo
    if (pr.phase === 'showdown'){
        // distribuir pot respetando side-pots
        distributePotWithSidePots(pr);
        const contenders = pr.players.filter(p=>p.active && !p.fold);
        const evalRes = pokerEngine.determineWinners(contenders, pr.community);
        if (evalRes && evalRes.winners && evalRes.winners.length > 0) {
            io.to(room).emit('pokerResult', { winners: evalRes.winners.map(w=>w.player.username), details: evalRes.all.map(r=>({ username: r.player.username, hand: r.best.name })) });
        }
        io.to(room).emit('pokerState', sanitizePokerState(pr));
        sendPrivateToOwners(room);
        savePersist();
    }
}

io.on("connection", (socket) => {
    console.log("Jugador conectado:", socket.id);

    // Enviar estado actual de asientos al nuevo cliente
    const publicSeats = {};
    for (let id in seats) publicSeats[id] = seats[id] ? seats[id].playerName : null;
    socket.emit('seatUpdate', publicSeats);

    // Determinar room solicitada en el handshake
    const room = (socket.handshake && socket.handshake.auth && socket.handshake.auth.room) || 'default_room';
    socket.room = room;
    socket.join(room);

    // Asegurar estructura de asientos para la room
    if (!roomsSeats[room]) {
        roomsSeats[room] = {
            1: null, 2: null, 3: null, 4: null,
            5: null, 6: null, 7: null, 8: null
        };
    }

    // Enviar estado actual de asientos al nuevo cliente (solo de su room)
    const publicSeatsRoom = {};
    for (let id in roomsSeats[room]) publicSeatsRoom[id] = roomsSeats[room][id] ? roomsSeats[room][id].playerName : null;
    socket.emit('seatUpdate', publicSeatsRoom);

    // Asegurar existencia del juego de la sala y enviar estado inicial
    const roomGame = ensureRoomGame(room);
    io.to(socket.id).emit('state', roomGame);

    // Reasignación en reconexión: si el username ya tenía un slot en players, reasignar socketId
    let reassignedPid = null;
    for (const pid of [1,2]) {
        const p = roomGame.players[pid];
        if (p && p.username && p.username === socket.username) {
            p.socketId = socket.id;
            p.alive = (typeof p.alive === 'undefined') ? true : p.alive;
            reassignedPid = pid;
        }
    }
    if (reassignedPid) {
        socket.emit('playerAssigned', { pid: reassignedPid });
    }

    // Reasignar seat si estaba reservado por username
    const roomSeatsRef = roomsSeats[room];
    if (roomSeatsRef) {
        let seatChanged = false;
        for (let id in roomSeatsRef) {
            const entry = roomSeatsRef[id];
            if (entry && entry.playerName === socket.username) {
                entry.socketId = socket.id;
                seatChanged = true;
            }
        }
        if (seatChanged) {
            const publicSeats = {};
            for (let id in roomSeatsRef) publicSeats[id] = roomSeatsRef[id] ? roomSeatsRef[id].playerName : null;
            io.to(room).emit('seatUpdate', publicSeats);
        }
    }

    // Enviar lista de rooms disponible para el lobby
    function computeRoomsList() {
        const rooms = [];
        for (const r in roomsGame) {
            const rg = roomsGame[r];
            // contar jugadores vivos/asignados
            let playersCount = 0;
            for (const pid of [1,2]) if (rg.players[pid] && rg.players[pid].username) playersCount++;
            // contar asientos ocupados si existen
            const seatsRef = roomsSeats[r] || {};
            let seatsOccupied = 0;
            for (const sid in seatsRef) if (seatsRef[sid]) seatsOccupied++;
            rooms.push({ room: r, players: playersCount, seats: seatsOccupied, gameType: rg.gameType || 'omaha' });
        }
        return rooms;
    }

        

    // Emitir lista al cliente conectado
    socket.emit('roomsList', computeRoomsList());

    socket.on('getRooms', () => {
        console.log('getRooms request from', socket.username, 'socket', socket.id);
        socket.emit('roomsList', computeRoomsList());
    });

    socket.on('createRoom', ({ roomName, gameType }, cb) => {
        const name = String(roomName || '').trim();
        const gtype = String(gameType || 'omaha').trim();
        console.log('createRoom request:', { from: socket.username, socketId: socket.id, name, gtype });
        if (!name) return cb && cb({ ok: false, error: 'Invalid name' });
        if (roomsGame[name] || roomsSeats[name]) return cb && cb({ ok: false, error: 'Room exists' });
        // crear estructuras
        roomsSeats[name] = { 1: null,2: null,3: null,4: null,5: null,6: null,7: null,8: null };
        const board = createRoomBoard();
        roomsGame[name] = { grid: board.grid, ROWS: board.ROWS, COLS: board.COLS, players: {1:null,2:null}, bombs: [], gameType: gtype };
        // anunciar a todos los conectados
        console.log('Room created:', name, 'gameType:', gtype);
        io.emit('roomsList', computeRoomsList());
        savePersist();
        return cb && cb({ ok: true });
    });

    // Poker-specific socket events
    socket.on('poker:join', ({ room }) => {
        const pr = createPokerRoom(room);
        // add player if not present
        let p = pr.players.find(x=>x.username === socket.username);
        if (!p) {
            p = { username: socket.username, socketId: socket.id, stack: 10000, seat: pr.players.length+1, active: true, fold: false, cards: [], currentBet: 0, committed: 0 };
            pr.players.push(p);
        } else {
            p.socketId = socket.id; p.active = true;
        }
        io.to(room).emit('pokerState', sanitizePokerState(pr));
        sendPrivateToOwners(room);
        savePersist();
    });

    socket.on('poker:start', ({ room }) => {
        const res = startPokerHand(room);
        if (res && res.error) socket.emit('pokerError', res.error);
        else {
            // after starting, send private cards
            sendPrivateToOwners(room);
            savePersist();
        }
    });

    socket.on('poker:action', ({ room, action }) => {
        handlePokerAction(room, socket.username, action);
    });

    // Omaha-specific events
    socket.on('omaha:join', ({ room }) => {
        const pr = createOmahaRoom(room);
        let p = pr.players.find(x=>x.username === socket.username);
        if (!p) { p = { username: socket.username, socketId: socket.id, stack: 10000, seat: pr.players.length+1, active: true, fold: false, cards: [], currentBet: 0 }; pr.players.push(p); }
        else { p.socketId = socket.id; p.active = true; }
        io.to(room).emit('omahaState', { players: pr.players.map(pp=>({username:pp.username,stack:pp.stack,active:pp.active,fold:pp.fold,seat:pp.seat})), community: pr.community, pot: pr.pot, phase: pr.phase });
        sendPrivateToOwnersOmaha(room);
    });

    socket.on('omaha:start', ({ room }) => {
        const res = startOmahaHand(room);
        if (res && res.error) socket.emit('omahaError', res.error);
    });

    socket.on('omaha:action', ({ room, action }) => {
        // For now reuse poker action handler on the omaha room structure (similar rules)
        const pr = omahaRooms[room];
        if (!pr) return;
        // find player
        const idx = pr.players.findIndex(p=>p.username===socket.username);
        if (idx === -1) return;
        const player = pr.players[idx];
        if (!player.active || player.fold) return;

        // simple action handling (fold/call/raise/check)
        switch(action.type){
            case 'fold': player.fold = true; break;
            case 'call': {
                const toCall = pr.betToCall - (player.currentBet||0);
                const commit = Math.min(toCall, player.stack);
                player.stack -= commit; pr.pot += commit; player.currentBet = (player.currentBet||0)+commit;
            } break;
            case 'raise': {
                const raiseAmount = Number(action.amount) || pr.minBet;
                const total = (pr.betToCall - (player.currentBet||0)) + raiseAmount;
                if (player.stack >= total){ player.stack -= total; pr.pot += total; player.currentBet = (player.currentBet||0)+total; pr.betToCall = player.currentBet; pr.minBet = raiseAmount; }
                else { const allin = player.stack; player.stack = 0; pr.pot += allin; player.currentBet = (player.currentBet||0)+allin; if (player.currentBet > pr.betToCall) pr.betToCall = player.currentBet; }
            } break;
        }

        pr.currentPlayerIndex = nextIndex(pr, idx);

        const activePlayers = pr.players.filter(p=>p.active && !p.fold);
        let roundOver = activePlayers.every(p=> (p.currentBet||0) === pr.betToCall || p.stack===0);
        if (roundOver){
            if (pr.phase === 'preflop'){ pr.phase = 'flop'; pr.deck.pop(); pr.community.push(pr.deck.pop()); pr.community.push(pr.deck.pop()); pr.community.push(pr.deck.pop()); }
            else if (pr.phase === 'flop'){ pr.phase = 'turn'; pr.deck.pop(); pr.community.push(pr.deck.pop()); }
            else if (pr.phase === 'turn'){ pr.phase = 'river'; pr.deck.pop(); pr.community.push(pr.deck.pop()); }
            else if (pr.phase === 'river'){ pr.phase = 'showdown'; }
            for (const p of pr.players) p.currentBet = 0; pr.betToCall = 0;
        }

        io.to(room).emit('omahaState', { players: pr.players.map(pp=>({username:pp.username,stack:pp.stack,active:pp.active,fold:pp.fold,seat:pp.seat,currentBet:pp.currentBet})), community: pr.community, pot: pr.pot, phase: pr.phase, betToCall: pr.betToCall, dealerIndex: pr.dealerIndex, currentPlayerIndex: pr.currentPlayerIndex });
        sendPrivateToOwnersOmaha(room);

        if (pr.phase === 'showdown'){
            const contenders = pr.players.filter(p=>p.active && !p.fold);
            const res = omahaEngine.determineOmahaWinners(contenders, pr.community);
            if (res && res.winners && res.winners.length > 0) {
                const winners = res.winners.map(w => w.player);
                const share = Math.floor(pr.pot / winners.length);
                for (const w of winners) w.stack += share;
                const remainder = pr.pot - share * winners.length;
                if (remainder > 0) winners[0].stack += remainder;
                pr.pot = 0;
                io.to(room).emit('omahaResult', { winners: winners.map(w=>w.username), details: res.all.map(r=>({ username: r.player.username, hand: r.best.name })) });
            }
            io.to(room).emit('omahaState', { players: pr.players.map(pp=>({username:pp.username,stack:pp.stack,active:pp.active,fold:pp.fold,seat:pp.seat})), community: pr.community, pot: pr.pot, phase: pr.phase });
            sendPrivateToOwnersOmaha(room);
        }
    });

    socket.on("joinSeat", ({ seatId }) => {
        // Asegurarse que el asiento esté libre
            if (!seatId) return;
            const roomSeats = roomsSeats[socket.room];
            if (!roomSeats) return;
            if (!roomSeats[seatId]) {
                roomSeats[seatId] = { socketId: socket.id, playerName: socket.username || 'Anon' };

                const publicSeats = {};
                for (let id in roomSeats) publicSeats[id] = roomSeats[id] ? roomSeats[id].playerName : null;
                io.to(socket.room).emit("seatUpdate", publicSeats);
                savePersist();
            }
    });

        // Jugador solicita unirse al juego (se asigna slot 1 o 2)
        socket.on('playerJoin', () => {
            const roomGame = ensureRoomGame(socket.room);
            // buscar slot libre
            let assigned = null;
            for (const pid of [1,2]) {
                const p = roomGame.players[pid];
                if (!p || !p.username) {
                    roomGame.players[pid] = { username: socket.username, row: pid === 1 ? 1 : roomGame.ROWS - 2, col: pid === 1 ? 1 : roomGame.COLS - 2, alive: true, socketId: socket.id };
                    assigned = pid;
                    break;
                }
            }
            socket.emit('playerAssigned', { pid: assigned });
            io.to(socket.room).emit('state', roomGame);
        });

        // Movimiento
        socket.on('playerMove', ({ pid, dr, dc }) => {
            const roomGame = roomsGame[socket.room];
            if (!roomGame) return;
            const player = roomGame.players[pid];
            if (!player || player.username !== socket.username || !player.alive) return;
            const nr = player.row + dr;
            const nc = player.col + dc;
            if (!isWalkableGrid(roomGame, nr, nc)) return;
            player.row = nr; player.col = nc;
            io.to(socket.room).emit('state', roomGame);
        });

        // Colocar bomba
        socket.on('placeBomb', ({ pid }) => {
            const roomGame = roomsGame[socket.room];
            if (!roomGame) return;
            const player = roomGame.players[pid];
            if (!player || player.username !== socket.username || !player.alive) return;
            const r = player.row, c = player.col;
            if (roomGame.grid[r][c] === 'bomb') return;
            roomGame.grid[r][c] = 'bomb';
            // schedule explosion
            setTimeout(() => {
                // si el juego sigue
                if (!roomsGame[socket.room]) return;
                // limpiar bomba
                if (roomsGame[socket.room].grid[r][c] === 'bomb') roomsGame[socket.room].grid[r][c] = 'empty';
                serverExplodeBomb(socket.room, r, c);
            }, 2000);
            io.to(socket.room).emit('state', roomGame);
        });

    socket.on('leaveSeat', ({ seatId }) => {
            const roomSeats = roomsSeats[socket.room];
            if (!roomSeats) return;
            if (roomSeats[seatId] && roomSeats[seatId].socketId === socket.id) {
                roomSeats[seatId] = null;
                const publicSeats = {};
                for (let id in roomSeats) publicSeats[id] = roomSeats[id] ? roomSeats[id].playerName : null;
                io.to(socket.room).emit('seatUpdate', publicSeats);
                savePersist();
            }
    });

    socket.on("disconnect", () => {
            const roomSeats = roomsSeats[socket.room];
            if (roomSeats) {
                for (let id in roomSeats) {
                    if (roomSeats[id] && roomSeats[id].socketId === socket.id) roomSeats[id] = null;
                }
                const publicSeats = {};
                for (let id in roomSeats) publicSeats[id] = roomSeats[id] ? roomSeats[id].playerName : null;
                io.to(socket.room).emit("seatUpdate", publicSeats);
                savePersist();
            }
    });
});

// Load persisted state (if any) then start server
loadPersist();
http.listen(3000, () => {
    console.log("Servidor multijuego corriendo en puerto 3000");
});