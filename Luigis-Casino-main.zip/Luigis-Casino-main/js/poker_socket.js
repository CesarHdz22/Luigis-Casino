// Cliente ligero para Poker Texas (socket)
(async function(){
    if (!document.getElementById) return;
    // Obtener usuario y room desde URL o desde DOM
    function getParam(name){ const u=new URL(location.href); return u.searchParams.get(name); }
    const ROOM = getParam('mesa') || getParam('id') || 'default_poker';

    // pedir token
    try{
        const resp = await fetch('get_socket_token.php');
        if (resp.status === 401){ location.href = '/login.php'; return; }
        const data = await resp.json();
        const token = data.token;
        const socket = io('http://localhost:3000', { auth: { token, room: ROOM } });

        socket.on('connect', ()=>{ console.log('poker socket connected'); socket.emit('poker:join', { room: ROOM }); });

        socket.on('pokerState', (state)=>{
            // render minimal: players, pot, community
            if (window.renderPokerState) window.renderPokerState(state);
        });

        socket.on('pokerPrivate', (data)=>{
            if (window.renderPokerPrivate) window.renderPokerPrivate(data);
        });

        window._pokerSocket = socket;
    } catch(e){ console.error('poker socket error', e); }
})();
