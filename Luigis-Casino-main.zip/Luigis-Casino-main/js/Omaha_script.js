let socket = null;
document.addEventListener('DOMContentLoaded', () => {

    const playerNameDisplay = document.getElementById("playerNameDisplay");
    if (!playerNameDisplay) return;

    const PLAYER_NAME = playerNameDisplay.textContent.trim();
    const balanceEl = document.getElementById("balance");
    const potEl = document.getElementById("pot");
    const holeEl = document.getElementById("holeCards"); 
    const communityEl = document.getElementById("community");
    const betAmountInput = document.getElementById('betAmount');
    
    let playerStack = parseInt(balanceEl.textContent) || 1000;
    let currentPot = 0;
    let minBet = 10;
    let playerSeatId = null;
    let gameActive = false; 
    let playerHand = []; 

    const SIMULATED_COMMUNITY = ['Qd', 'Jc', '3s']; 
    
    let seatElement = null; 
    let seatInfoElement = null; 

    const suits = ['♥', '♦', '♣', '♠'];
    const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'];

    function createDeck() {
        let deck = [];
        for (const suit of suits) {
            for (const rank of ranks) {
                deck.push(rank + suit); 
            }
        }
        return deck;
    }

    function shuffleDeck(deck) {
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
        return deck;
    }

    function dealHand(deck, numCards = 4) {
        return deck.splice(0, numCards); 
    }

    function getNewRandomHand() {
        let deck = createDeck();
        deck = shuffleDeck(deck);
        return dealHand(deck, 4); 
    }
    
    const joinBtnLobby = document.getElementById('joinBtn');
    if (joinBtnLobby) {
        joinBtnLobby.addEventListener('click', () => {
            const name = document.getElementById('playerName').value.trim();
            if (name === "") {
                alert("Ingresa un nombre");
                return;
            }
            window.location = `omaha_table.php?usuarios=${encodeURIComponent(name)}`;
        });
    }

    function updateDisplay() {
        balanceEl.textContent = playerStack; 
        
        potEl.textContent = currentPot;
        
        if (gameActive && seatInfoElement) {
            seatInfoElement.innerHTML = 
                `<strong>${PLAYER_NAME}</strong><br>Stack: $${playerStack}`;
        }
        
        document.getElementById('btnCheck').textContent = (currentPot > 0 && minBet > 0) ? `Call $${minBet}` : 'Check';
    }

    function renderCards(element, cards) {
    element.innerHTML = "";
    cards.forEach(card => {
        const div = document.createElement("div");
        div.classList.add("card");
        
        const rank = card.substring(0, card.length - 1); 
        const suit = card.charAt(card.length - 1); 

        div.style.display = 'flex';
        div.style.flexDirection = 'column';
        div.style.justifyContent = 'space-between';
        div.style.alignItems = 'center';
        div.style.padding = '3px 0'; 

        const rankEl = document.createElement("span");
        rankEl.textContent = rank;
        rankEl.style.fontSize = '1.2rem';
        rankEl.style.fontWeight = 'bold'; 
        div.appendChild(rankEl);
        
        const suitEl = document.createElement("span");
        suitEl.textContent = suit;
        suitEl.style.fontSize = '0.7rem';
        div.appendChild(suitEl);
        
        if (suit === '♦' || suit === '♥') {
            div.style.color = '#dc3545'; 
        } else {
            div.style.color = '#000000'; 
        }

        element.appendChild(div);
    });
}

    function renderCommunity(cards) {
    communityEl.innerHTML = "";
    const maxCards = 5;
    
    for (let i = 0; i < maxCards; i++) {
        const div = document.createElement("div");
        
        if (cards[i]) {
            div.classList.add("card");
            
            const cardValue = cards[i];
            const rank = cardValue.substring(0, cardValue.length - 1); 
            let suit = cardValue.charAt(cardValue.length - 1); 
            
            if (suit === 'd') suit = '♦'; 
            else if (suit === 'c') suit = '♣'; 
            else if (suit === 'h') suit = '♥';
            else if (suit === 's') suit = '♠';

            
            div.style.display = 'flex';
            div.style.flexDirection = 'column';
            div.style.justifyContent = 'space-between';
            div.style.alignItems = 'center';
            div.style.padding = '3px 0';

            const rankEl = document.createElement("span");
            rankEl.textContent = rank;
            rankEl.style.fontSize = '1.2rem';
            rankEl.style.fontWeight = 'bold';
            div.appendChild(rankEl);
            
            const suitEl = document.createElement("span");
            suitEl.textContent = suit;
            suitEl.style.fontSize = '0.7rem';
            div.appendChild(suitEl);

            if (suit === '♦' || suit === '♥') {
                div.style.color = '#dc3545'; 
            } else {
                div.style.color = '#000000'; 
            }

        } else {
            div.classList.add("card-slot");
        }
        communityEl.appendChild(div);
    }
}


    const joinButtons = document.querySelectorAll('.join-btn');

    // Inicializar conexión Socket.io con token obtenido desde PHP
    (async function initSocket(){
        try {
            const roomId = (window && window.ROOM_ID) ? window.ROOM_ID : 'omaha_main';
            const resp = await fetch('get_socket_token.php');
            if (resp.status === 401) {
                // No hay sesión: redirigir a login
                window.location.href = '/login.php';
                return;
            }
            if (!resp.ok) throw new Error('No token');
            const data = await resp.json();
            const token = data.token;
            socket = io("http://localhost:3000", { auth: { token, room: roomId } });

            socket.on('connect', () => {
                console.log('Conectado a socket.io como', socket.id);
            });

            // Enviar petición para unirse a un asiento cuando se pulse el botón
            joinButtons.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();

                    if (gameActive) return;

                    const seatId = e.target.dataset.seat;
                    socket.emit('joinSeat', { seatId, playerName: PLAYER_NAME });
                });
            });

            // Escuchar actualizaciones de asientos desde el servidor
            socket.on('seatUpdate', (seats) => {
                // seats: { '1': 'name' | null, ... }
                for (const id in seats) {
                    const name = seats[id];
                    const infoEl = document.getElementById(`seatInfo-${id}`);
                    const btn = document.querySelector(`.join-btn[data-seat="${id}"]`);
                    if (infoEl) infoEl.innerHTML = name ? `<strong>${name}</strong>` : `ASIENTO ${id}`;
                    if (btn) btn.style.display = name ? 'none' : 'inline-block';
                }

                // Si el servidor nos asignó un asiento (por nombre), iniciamos la mano localmente
                const mySeat = Object.keys(seats).find(id => seats[id] === PLAYER_NAME);
                if (mySeat) {
                    if (!gameActive) {
                        playerSeatId = mySeat;
                        gameActive = true;
                        seatElement = document.querySelector(`.seat-${mySeat}`);
                        seatInfoElement = seatElement ? seatElement.querySelector('.player-info') : null;
                        if (seatElement) seatElement.style.borderColor = '#ffd700';
                        joinButtons.forEach(b => b.style.display = 'none');

                        playerHand = getNewRandomHand();
                        renderCards(holeEl, playerHand);
                        renderCommunity(SIMULATED_COMMUNITY);

                        currentPot = 20;
                        playerStack -= 10;
                        minBet = 10;
                        updateDisplay();
                        alert(`¡Te uniste al Asiento ${mySeat}! Tu mano: ${playerHand.join(', ')}`);
                    }
                } else {
                    // Si perdimos el asiento en el update, salir de la mano
                    if (gameActive && playerSeatId && !seats[playerSeatId]) {
                        gameActive = false;
                        playerSeatId = null;
                        holeEl.innerHTML = "<div>Folded</div>";
                    }
                }
            });

        } catch (err) {
            console.error('Error inicializando socket', err);
            alert('No se pudo inicializar la conexión en tiempo real.');
        }
    })();

    document.getElementById('btnFold').onclick = () => {
        if (!gameActive) return;
        alert("Fold: Has abandonado la mano.");
        // Notificar al servidor que dejamos el asiento
        if (playerSeatId) {
            socket.emit('leaveSeat', { seatId: playerSeatId });
        }
        gameActive = false;
        holeEl.innerHTML = "<div>Folded</div>";
    };

    document.getElementById('btnCheck').onclick = () => {
        if (!gameActive) return;

        if (minBet > 0) {
            
            const callAmount = minBet;
            if (playerStack >= callAmount) {
                playerStack -= callAmount;
                currentPot += callAmount;
                minBet = 0; 
                alert(`Call: Pagaste $${callAmount}.`);
            } else {
                alert("No tienes suficiente dinero para Call.");
            }
        } else {
            
            alert("Check: Pasaste la acción.");
        }
        updateDisplay(); 
    };

    document.getElementById('btnBet').onclick = () => {
        if (!gameActive) return;
        
        let betAmount = Number(betAmountInput.value) || 0;
        
        if (betAmount <= 0) {
            alert("Ingresa una cantidad válida.");
            return;
        }

        if (playerStack >= betAmount) {
            playerStack -= betAmount;
            currentPot += betAmount;
            minBet = betAmount; 
            alert(`Bet/Raise: Apostaste $${betAmount}.`);
        } else {
            alert("No tienes suficiente dinero para esa apuesta.");
        }
        updateDisplay(); 
    };


    updateDisplay(); 

});