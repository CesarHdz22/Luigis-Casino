<?php
session_start();

// Si el usuario NO ha iniciado sesión, lo mandamos al login
if (empty($_SESSION['Id_Usuario'])) {
    header("Location: index.html");
    exit();
}

// Obtener el juego elegido
$juego = isset($_GET['juego']) ? $_GET['juego'] : '';

$nombreJuego = "";

// Traducimos el valor en texto bonito
switch ($juego) {
    case "texas":
        $nombreJuego = "Poker Texas Hold'em";
        break;
    case "omaha":
        $nombreJuego = "Poker Omaha";
        break;
    case "memorama":
        $nombreJuego = "Memorama";
        break;
    case "mini":
        $nombreJuego = "Mini-Juego Especial";
        break;
    default:
        $nombreJuego = "Juego desconocido";
        break;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luigi's Casino - Mesas</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/mesas.css">
    <link rel="shortcut icon" href="css/assets/iconoLuigi.png">
</head>
<body>

    <header class="casino-header">
        <h1 class="casino-title"> Luigi's Casino</h1>
        <div class="user-info">
            <span class="username">Bienvenido, <strong>Usuario123</strong></span>
            <a href=""><img src="css/assets/salida.png" alt="Cerrar Sesion" width="30px" class="logout-btn"></a>
        </div>
    </header>

    <main class="casino-menu">
        <h2 class="title">Elige una mesa para jugar</h2>

        <div>
            <div style="margin-bottom:12px">
                <input id="newRoomName" placeholder="Nombre de nueva mesa" />
                <!-- El tipo de juego está fijado por la elección previa -->
                <button id="createRoomBtn">Crear Mesa</button>
            </div>
            <div class="mesas-container" id="roomsList">
                <p>Cargando mesas...</p>
            </div>
        </div>
    </main>

    <script src="http://localhost:3000/socket.io/socket.io.js"></script>
    <script>
    (async function(){
        // solicitar token para conectar socket
        try {
            const resp = await fetch('get_socket_token.php');
            if (resp.status === 401) { location.href = '/login.php'; return; }
            const data = await resp.json();
            const token = data.token;
            const socket = io('http://localhost:3000', { auth: { token } });

            const roomsEl = document.getElementById('roomsList');
            const input = document.getElementById('newRoomName');
            const btn = document.getElementById('createRoomBtn');

            // Juego seleccionado desde PHP (cadena tal cual, puede estar vacía)
            const SELECTED_GAME = <?= json_encode($juego) ?>;
            const USER_NAME = <?= json_encode(isset($_SESSION['User']) ? $_SESSION['User'] : '') ?>;

            function renderRooms(list){
                if (!list) list = [];
                // aceptar ambos formatos: array directo o { rooms: [...] }
                if (!Array.isArray(list) && list.rooms && Array.isArray(list.rooms)) list = list.rooms;
                // Filtrar según gameType. Si SELECTED_GAME es vacío, mostrar todas.
                const filtered = list.filter(r => {
                    if (!r || !r.gameType) return false;
                    if (!SELECTED_GAME || SELECTED_GAME === '') return true;
                    return String(r.gameType).toLowerCase() === String(SELECTED_GAME).toLowerCase();
                });
                if (filtered.length === 0) { roomsEl.innerHTML = '<p>No hay mesas para este juego. Crea una.</p>'; return; }
                roomsEl.innerHTML = '';
                filtered.forEach(r => {
                    const a = document.createElement('a');
                    a.className = 'mesa-link';
                    let href = '#';
                    // Mapear a la página correcta según el juego seleccionado
                    if (SELECTED_GAME === 'omaha') {
                        href = `omaha_table.php?mesa=${encodeURIComponent(r.room)}&usuarios=${encodeURIComponent(USER_NAME)}`;
                    } else if (SELECTED_GAME === 'texas') {
                        href = `juego.php?id=${encodeURIComponent(r.room)}`;
                    } else if (SELECTED_GAME === 'bomberman') {
                        href = `bomberman.html?mesa=${encodeURIComponent(r.room)}`;
                    } else if (SELECTED_GAME === 'memorama') {
                        href = `juego.php?juego=memorama&id=${encodeURIComponent(r.room)}`;
                    } else {
                        href = `juego.php?id=${encodeURIComponent(r.room)}`;
                    }
                    a.href = href;
                    a.innerHTML = `<div class="mesa-card"><div class="mesa-img"></div><h3>${r.room} <small style="font-size:12px">(${r.gameType})</small></h3><p class="jugadores">Jugadores: ${r.players} | Asientos ocupados: ${r.seats}</p></div>`;
                    roomsEl.appendChild(a);
                });
            }

            socket.on('connect', ()=>{ console.log('socket connected', socket.id); socket.emit('getRooms'); });
            socket.on('connect_error', (err)=>{ console.error('socket connect_error', err); });
            socket.on('disconnect', (reason)=>{ console.log('socket disconnected', reason); });
            socket.on('roomsList', (list)=>{ console.log('roomsList received', list); renderRooms(list); });

            btn.addEventListener('click', ()=>{
                const name = input.value.trim();
                const gtype = SELECTED_GAME || 'omaha';
                console.log('CreateRoom click', { name, gtype, socketId: socket && socket.id });
                if (!name) return alert('Ingresa nombre');
                if (!socket || !socket.connected) { return alert('No conectado al servidor de salas. Revisa la consola.'); }
                socket.emit('createRoom', { roomName: name, gameType: gtype }, (res)=>{
                    console.log('createRoom callback', res);
                    if (!res || !res.ok) return alert('Error: ' + (res && res.error ? res.error : 'no creado'));
                    input.value = '';
                    socket.emit('getRooms');
                });
            });

        } catch (e) { console.error(e); alert('No se pudo conectar al lobby en tiempo real. Asegúrate de que el servidor Node (socket) esté corriendo en http://localhost:3000 y que hayas instalado las dependencias (npm install).'); }
    })();
    </script>



</body>
</html>
