<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luigi's Casino - Juego</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/juego.css">
    <link rel="shortcut icon" href="css/assets/iconoLuigi.png">
</head>
<body>

    <header class="casino-header">
        <h1 class="casino-title"> Luigi's Casino</h1>
        <div class="user-info">
            <span class="username">Bienvenido, <strong>Usuario123</strong></span>
            <a href=""><img src="css/assets/salida.png" alt="Cerrar Sesion" width="30px" class="logout-btn"></a>
        </div>
    </header>

    <main class="casino-menu">

        
        <div id="player-money"></div>

        <div class="mesa-container">

           
            <div id="dealer-area">
            <video id="dealer-video" src="css/assets/luigi-casino.mp4" muted loop></video>
            </div>

            <div class="mesa">
                <div class="felt">

                    <div class="center-area">

                        <div class="community">
                            <div class="card-slot" id="c1"></div>
                            <div class="card-slot" id="c2"></div>
                            <div class="card-slot" id="c3"></div>
                            <div class="card-slot" id="c4"></div>
                            <div class="card-slot" id="c5"></div>
                        </div>

                        <div class="pot">Pozo: $0</div>

                    </div>

                    <div class="actions">
                        <button id="btn-check">Check</button>
                        <button id="btn-call">Call</button>
                        <button id="btn-raise">Raise</button>
                        <button id="btn-fold">Fold</button>
                    </div>

                    <div id="players-container">

                        <div class="player" id="p1">
                            <div class="seat-box">
                                Jugador 1
                                <span class="stack">$10,000</span> 
                            </div>

                            <div class="hand">
                                <div class="card-slot"></div>
                                <div class="card-slot"></div>
                            </div>

                            <button class="join-btn">Unirme</button>
                        </div>

                        <div class="player" id="p2">
                            <div class="seat-box">
                                Jugador 2
                                <span class="stack">$10,000</span>
                            </div>
                            <div class="hand">
                                <div class="card-slot"></div>
                                <div class="card-slot"></div>
                            </div>
                            <button class="join-btn">Unirme</button>
                        </div>

                        <div class="player" id="p3">
                            <div class="seat-box">
                                Jugador 3
                                <span class="stack">$10,000</span>
                            </div>
                            <div class="hand">
                                <div class="card-slot"></div>
                                <div class="card-slot"></div>
                            </div>
                            <button class="join-btn">Unirme</button>
                        </div>

                        <div class="player" id="p4">
                            <div class="seat-box">
                                Jugador 4
                                <span class="stack">$10,000</span>
                            </div>
                            <div class="hand">
                                <div class="card-slot"></div>
                                <div class="card-slot"></div>
                            </div>
                            <button class="join-btn">Unirme</button>
                        </div>

                        <div class="player" id="p5">
                            <div class="seat-box">
                                Jugador 5
                                <span class="stack">$10,000</span>
                            </div>
                            <div class="hand">
                                <div class="card-slot"></div>
                                <div class="card-slot"></div>
                            </div>
                            <button class="join-btn">Unirme</button>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <div id="game-controls">
    <button id="btn-start">Start</button>
    <button id="btn-reset">Reset</button>
</div>
    </main>




</body>
<script src="js/texas.js"></script>
<script src="http://localhost:3000/socket.io/socket.io.js"></script>
<script src="js/poker_socket.js"></script>
<script>
    // Bridge between server state and existing UI functions in `js/texas.js`.
    // We implement minimal renderers that replace local-only logic when server sends state.

    function renderPokerState(state){
        if (!state) return;
        // actualizar pot
        const potDiv = document.querySelector('.pot');
        if(potDiv) potDiv.textContent = `Pozo: $${state.pot || 0}`;

        // actualizar players por seat (si está presente)
        state.players.forEach((p, i)=>{
            const seat = p.seat || (i+1);
            const el = document.getElementById(`p${seat}`) || document.getElementById(`p${i+1}`);
            if (!el) return;
            const stackEl = el.querySelector('.stack');
            if (stackEl) stackEl.textContent = `$${(p.stack||0).toLocaleString()}`;
            const joinBtn = el.querySelector('.join-btn');
            if (p.active) { if (joinBtn) joinBtn.style.display='none'; el.style.opacity='1'; } else { if (joinBtn) joinBtn.style.display='block'; el.style.opacity = 0.6; }
        });

        // community
        for (let i=0;i<5;i++){
            const c = document.getElementById(`c${i+1}`);
            if (!c) continue;
            c.innerHTML = '';
            if (state.community && state.community[i]){
                const card = state.community[i];
                c.textContent = `${card.valor}${card.palo}`;
            }
        }
    }

    function renderPokerPrivate(data){
        // data should include { cards, seat }
        const myCards = data.cards || [];
        const seat = data.seat;
        if (seat) {
            const el = document.getElementById(`p${seat}`);
            if (el) {
                const hand = el.querySelector('.hand');
                if (hand){ hand.innerHTML = ''; myCards.forEach(c => { const div = document.createElement('div'); div.className='card-slot'; div.textContent = `${c.valor}${c.palo}`; hand.appendChild(div); }); }
                return;
            }
        }
        // fallback: place in first joined slot
        for (let i=1;i<=5;i++){
            const el = document.getElementById(`p${i}`);
            if (!el) continue;
            const joinBtn = el.querySelector('.join-btn');
            if (joinBtn && joinBtn.style.display === 'none'){
                const hand = el.querySelector('.hand');
                if (hand){ hand.innerHTML = ''; myCards.forEach(c => { const div = document.createElement('div'); div.className='card-slot'; div.textContent = `${c.valor}${c.palo}`; hand.appendChild(div); }); }
                break;
            }
        }
    }

    // disable join/start until socket is ready
    function setControlsEnabled(enabled){
        document.querySelectorAll('.join-btn').forEach(b => b.disabled = !enabled);
        const start = document.getElementById('btn-start'); if (start) start.disabled = !enabled;
    }
    setControlsEnabled(false);

    // wait for global socket to be available and attach connect handler
    (function waitSocketReady(){
        if (window._pokerSocket) {
            const s = window._pokerSocket;
            s.on('connect', ()=>{ setControlsEnabled(true); });
            s.on('disconnect', ()=>{ setControlsEnabled(false); });
            // in case already connected
            if (s.connected) setControlsEnabled(true);
            return;
        }
        setTimeout(waitSocketReady, 200);
    })();

    // Hook actions to emit to server
    document.querySelectorAll('.join-btn').forEach((btn, i)=>{
        btn.addEventListener('click', ()=>{ if (window._pokerSocket) window._pokerSocket.emit('poker:join', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa') }); });
    });

    document.getElementById('btn-start').addEventListener('click', ()=>{ if (window._pokerSocket) window._pokerSocket.emit('poker:start', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa') }); });

    document.getElementById('btn-reset').addEventListener('click', ()=>{ location.reload(); });

    // map action buttons
    document.getElementById('btn-check').addEventListener('click', ()=>{ if (window._pokerSocket) window._pokerSocket.emit('poker:action', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa'), action: { type: 'check' } }); });
    document.getElementById('btn-call').addEventListener('click', ()=>{ if (window._pokerSocket) window._pokerSocket.emit('poker:action', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa'), action: { type: 'call' } }); });
    document.getElementById('btn-raise').addEventListener('click', ()=>{ const amt = 200; if (window._pokerSocket) window._pokerSocket.emit('poker:action', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa'), action: { type: 'raise', amount: amt } }); });
    document.getElementById('btn-fold').addEventListener('click', ()=>{ if (window._pokerSocket) window._pokerSocket.emit('poker:action', { room: new URL(location.href).searchParams.get('id') || new URL(location.href).searchParams.get('mesa'), action: { type: 'fold' } }); });
</script>
</html>