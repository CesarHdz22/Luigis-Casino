<?php
session_start();

header('Content-Type: application/json');

// Requiere sesión establecida por `login.php`.
if (!isset($_SESSION['User']) || empty($_SESSION['User'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized: login required']);
    exit;
}

$username = $_SESSION['User'];

// Generar token aleatorio (32 hex chars)
try {
    $token = bin2hex(random_bytes(16));
} catch (Exception $e) {
    $token = bin2hex(openssl_random_pseudo_bytes(16));
}

$storeFile = __DIR__ . '/js/socket_tokens.json';
$store = [];
if (file_exists($storeFile)) {
    $content = file_get_contents($storeFile);
    $store = json_decode($content, true) ?: [];
}

// Podar tokens antiguos (mayores a 15 minutos)
$now = time();
$maxAge = 60 * 15;
foreach ($store as $t => $entry) {
    if (isset($entry['created']) && ($now - intval($entry['created'])) > $maxAge) {
        unset($store[$t]);
    }
}

// Asociar token -> username y timestamp
$store[$token] = ['username' => $username, 'created' => $now];

file_put_contents($storeFile, json_encode($store, JSON_PRETTY_PRINT));

echo json_encode(['token' => $token]);
exit;

?>
